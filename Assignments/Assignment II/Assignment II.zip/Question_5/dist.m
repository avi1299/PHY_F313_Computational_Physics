function r = dist(x,y,z)
%DIST Summary of this function goes here
%   Detailed explanation goes here
r=(x^2+y^2+z^2)^(1/2);
end

